/**********************************************************************************************************************
 *  COPYRIGHT
 *  -------------------------------------------------------------------------------------------------------------------
 *
 *                This software is copyright protected and proprietary to Vector Informatik GmbH.
 *                Vector Informatik GmbH grants to you only those rights as set out in the license conditions.
 *                All other rights remain with Vector Informatik GmbH.
 *  -------------------------------------------------------------------------------------------------------------------
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *          File:  TSC_SchM_EcuM.h
 *        Config:  s32k_dvc.dpa
 *   ECU-Project:  S32K144
 *
 *     Generator:  MICROSAR RTE Generator Version 4.19.0
 *                 RTE Core Version 1.19.0
 *       License:  CBD1800257
 *
 *   Description:  Header of wrapper software component for Bte-based Rte test cases
 *********************************************************************************************************************/
void TSC_EcuM_SchM_Enter_EcuM_ECUM_EXCLUSIVE_AREA_0();
void TSC_EcuM_SchM_Exit_EcuM_ECUM_EXCLUSIVE_AREA_0();
void TSC_EcuM_SchM_Enter_EcuM_ECUM_EXCLUSIVE_AREA_1();
void TSC_EcuM_SchM_Exit_EcuM_ECUM_EXCLUSIVE_AREA_1();
void TSC_EcuM_SchM_Enter_EcuM_ECUM_EXCLUSIVE_AREA_2();
void TSC_EcuM_SchM_Exit_EcuM_ECUM_EXCLUSIVE_AREA_2();
